function [out_args] = Sobrepaso (zita)
out_args=exp(-(pi*zita)/sqrt(1-zita^2));
end
